function [out1 out2] = testCondorFunction(arg1,arg2)
    out1 = arg1 + arg2;
    out2 = arg1 - arg2;
    fprintf(['Hello World \n'];
end
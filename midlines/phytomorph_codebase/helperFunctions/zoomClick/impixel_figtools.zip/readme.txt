Main Entry M-File: impixel_figtools.m

Demo Run/Example:
RGB = imread('peppers.png');
pixels = impixel_figtools(RGB)